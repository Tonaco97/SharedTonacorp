
package com.example.clipshare

import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.widget.*
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.clipshare.ws.SignalService
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import java.io.ByteArrayOutputStream
import java.io.InputStream

class MainActivity : AppCompatActivity() {

    private val SIGNAL_URL = "wss://SEU_DOMINIO_OU_IP:8080"

    private lateinit var service: SignalService
    private lateinit var clipboard: ClipboardManager

    private lateinit var statusText: TextView
    private lateinit var receivedPreview: TextView
    private lateinit var receivedImage: ImageView
    private lateinit var codeInput: EditText
    private lateinit var btnCreate: Button
    private lateinit var btnJoin: Button
    private lateinit var btnShare: Button
    private lateinit var btnSendImage: Button
    private lateinit var btnRevoke: Button
    private lateinit var btnCopyReceived: Button
    private lateinit var btnSaveImage: Button

    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
    private val adapter = moshi.adapter(Map::class.java)
    private var currentCode: String? = null
    private var lastImageBytes: ByteArray? = null

    private val pickImage = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            sendImageWithConsent(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        statusText = findViewById(R.id.statusText)
        receivedPreview = findViewById(R.id.receivedPreview)
        receivedImage = findViewById(R.id.receivedImage)
        codeInput = findViewById(R.id.codeInput)
        btnCreate = findViewById(R.id.btnCreate)
        btnJoin = findViewById(R.id.btnJoin)
        btnShare = findViewById(R.id.btnShare)
        btnSendImage = findViewById(R.id.btnSendImage)
        btnRevoke = findViewById(R.id.btnRevoke)
        btnCopyReceived = findViewById(R.id.btnCopyReceived)
        btnSaveImage = findViewById(R.id.btnSaveImage)

        service = SignalService(
            url = SIGNAL_URL,
            onMessage = { onSignalMessage(it) },
            onOpen = { runOnUiThread { status("Conectado ao servidor") } },
            onClosed = { runOnUiThread { status("Conexão encerrada") } },
            onFailure = { e -> runOnUiThread { status("Falha: ${e.message}") } }
        )
        service.connect()

        // Persistência do código (sem expiração até revogar)
        val prefs = getSharedPreferences("pairing", Context.MODE_PRIVATE)
        val saved = prefs.getString("code", null)
        if (saved != null) {
            currentCode = saved
            codeInput.setText(saved)
            status("Pareamento ativo com código persistente.")
        }

        btnCreate.setOnClickListener { sendJson(mapOf("type" to "create_persistent")) }
        btnJoin.setOnClickListener {
            val code = codeInput.text.toString().trim()
            if (code.isEmpty()) toast("Digite o código") else sendJson(mapOf("type" to "join_persistent", "code" to code))
        }
        btnShare.setOnClickListener { shareClipboardText() }
        btnSendImage.setOnClickListener {
            // Picker com consentimento
            try {
                pickImage.launch(arrayOf("image/*"))
            } catch (e: Exception) {
                toast("Falha ao abrir galeria: ${e.message}")
            }
        }
        btnRevoke.setOnClickListener {
            val code = currentCode ?: codeInput.text.toString().trim()
            if (code.isEmpty()) { toast("Nenhum código ativo"); return@setOnClickListener }
            AlertDialog.Builder(this)
                .setTitle("Revogar Pareamento")
                .setMessage("Deseja REVOGAR o pareamento atual? Ambos perderão o acesso até gerar/join novamente.")
                .setPositiveButton("Revogar") { _, _ ->
                    sendJson(mapOf("type" to "revoke", "code" to code))
                    prefs.edit().remove("code").apply()
                    currentCode = null
                    status("Pareamento revogado.")
                }
                .setNegativeButton("Cancelar", null)
                .show()
        }
        btnCopyReceived.setOnClickListener {
            val text = receivedPreview.text?.toString() ?: ""
            if (text.isBlank()) toast("Nada recebido ainda")
            else {
                clipboard.setPrimaryClip(ClipData.newPlainText("received", text))
                toast("Texto copiado para o clipboard")
            }
        }
        btnSaveImage.setOnClickListener {
            val bytes = lastImageBytes
            if (bytes == null) { toast("Nenhuma imagem recebida ainda"); return@setOnClickListener }
            saveImageToGallery(bytes)
        }
    }

    private fun onSignalMessage(msg: String) {
        val map = try { adapter.fromJson(msg) as Map<String, Any?> } catch (_: Exception) { null } ?: return
        when (map["type"]) {
            "created_persistent" -> {
                val code = (map["code"] ?: "").toString()
                currentCode = code
                getSharedPreferences("pairing", Context.MODE_PRIVATE).edit().putString("code", code).apply()
                runOnUiThread {
                    codeInput.setText(code)
                    AlertDialog.Builder(this)
                        .setTitle("Código Gerado (sem expiração)")
                        .setMessage("Compartilhe com seu par. O código ficará ativo até você revogar.\n\n$code")
                        .setPositiveButton("OK", null)
                        .show()
                    status("Pareamento criado (persistente).")
                }
            }
            "error" -> runOnUiThread { toast((map["message"] ?: "Erro").toString()) }
            "peer-joined" -> runOnUiThread { status("Par conectado.") }
            "clipboard-push" -> {
                val text = (map["text"] ?: "").toString()
                runOnUiThread {
                    receivedPreview.text = text
                    AlertDialog.Builder(this)
                        .setTitle("Texto Recebido")
                        .setMessage("Prévia:\n" + text.take(200))
                        .setPositiveButton("Copiar") { _, _ ->
                            clipboard.setPrimaryClip(ClipData.newPlainText("received", text))
                            toast("Copiado para o clipboard")
                        }
                        .setNegativeButton("Fechar", null)
                        .show()
                }
            }
            "image-push" -> {
                val b64 = (map["base64"] ?: "").toString()
                try {
                    val data = Base64.decode(b64, Base64.DEFAULT)
                    lastImageBytes = data
                    val bmp = BitmapFactory.decodeByteArray(data, 0, data.size)
                    runOnUiThread {
                        receivedImage.setImageBitmap(bmp)
                        toast("Imagem recebida — prévia exibida.")
                    }
                } catch (_: Exception) {
                    runOnUiThread { toast("Falha ao decodificar imagem recebida.") }
                }
            }
        }
    }

    private fun shareClipboardText() {
        if (!clipboard.hasPrimaryClip()) { toast("Clipboard vazio"); return }
        val item = clipboard.primaryClip?.getItemAt(0)
        val text = item?.coerceToText(this)?.toString() ?: ""
        if (text.isBlank()) { toast("Nada de texto"); return }
        val code = ensureCode()
        AlertDialog.Builder(this)
            .setTitle("Compartilhar Texto")
            .setMessage("Você está prestes a ENVIAR este texto ao seu par. Confirma?\n\nPrévia:\n" + text.take(200))
            .setPositiveButton("Enviar") { _, _ -> sendJson(mapOf("type" to "clipboard-push", "text" to text, "code" to code)) }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun sendImageWithConsent(uri: Uri) {
        val code = ensureCode()
        // Ler a imagem como bitmap, reduzir e comprimir para JPEG (qualidade 80) antes de enviar
        try {
            val input: InputStream? = contentResolver.openInputStream(uri)
            val bmp = BitmapFactory.decodeStream(input)
            input?.close()
            if (bmp == null) { toast("Falha ao ler imagem"); return }
            val scaled = scaleDown(bmp, 1600)
            val baos = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, 80, baos)
            val bytes = baos.toByteArray()
            val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)

            AlertDialog.Builder(this)
                .setTitle("Enviar Imagem")
                .setMessage("Você está prestes a ENVIAR esta imagem ao seu par. Confirma?")
                .setPositiveButton("Enviar") { _, _ ->
                    sendJson(mapOf("type" to "image-push", "base64" to b64, "mime" to "image/jpeg", "code" to code))
                    toast("Imagem enviada")
                }
                .setNegativeButton("Cancelar", null)
                .show()
        } catch (e: Exception) {
            toast("Erro ao processar imagem: ${e.message}")
        }
    }

    private fun scaleDown(bmp: Bitmap, maxSize: Int): Bitmap {
        val ratio = minOf(maxSize.toFloat()/bmp.width, maxSize.toFloat()/bmp.height)
        return if (ratio >= 1f) bmp else Bitmap.createScaledBitmap(bmp, (bmp.width*ratio).toInt(), (bmp.height*ratio).toInt(), true)
    }

    private fun saveImageToGallery(bytes: ByteArray) {
        val name = "couple_${System.currentTimeMillis()}.jpg"
        val contentValues = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/CoupleShare")
            }
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
        if (uri == null) { toast("Falha ao criar arquivo na galeria"); return }
        contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
        toast("Imagem salva na galeria")
    }

    private fun ensureCode(): String {
        val c = currentCode ?: codeInput.text.toString().trim()
        if (c.isEmpty()) {
            toast("Nenhum código ativo. Gere ou entre com um código.")
            throw IllegalStateException("no code")
        }
        return c
    }

    private fun sendJson(map: Map<String, Any?>) {
        val json = adapter.toJson(map)
        service.send(json)
    }

    private fun status(s: String) { statusText.text = "Status: $s" }
    private fun toast(s:String){ Toast.makeText(this, s, Toast.LENGTH_SHORT).show() }
}
