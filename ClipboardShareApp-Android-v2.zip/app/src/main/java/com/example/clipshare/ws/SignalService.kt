
package com.example.clipshare.ws

import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import java.util.concurrent.TimeUnit

class SignalService(
    private val url: String,
    private val onMessage: (String) -> Unit,
    private val onOpen: () -> Unit = {},
    private val onClosed: () -> Unit = {},
    private val onFailure: (Throwable) -> Unit = {}
) {
    private val client = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()
    private var ws: WebSocket? = null

    fun connect() {
        val req = Request.Builder().url(url).build()
        ws = client.newWebSocket(req, object: WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: okhttp3.Response) { onOpen() }
            override fun onMessage(webSocket: WebSocket, text: String) { onMessage(text) }
            override fun onMessage(webSocket: WebSocket, bytes: ByteString) { onMessage(bytes.utf8()) }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { onClosed() }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: okhttp3.Response?) { onFailure(t) }
        })
    }
    fun send(json: String) { ws?.send(json) }
    fun close() { ws?.close(1000, "bye"); ws = null }
}
