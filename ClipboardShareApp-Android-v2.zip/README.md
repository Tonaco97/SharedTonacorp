
# CoupleShare (Android) — Clipboard + Imagens com Pareamento Persistente
**Para casais** que desejam compartilhar texto do clipboard e **imagens da galeria**, com **consentimento explícito**, usando um **código sigiloso sem expiração** (até revogar).

## Novidades desta versão (v2)
- Pareamento **persistente** (sem expiração) salvo no app até **revogação**.
- **Seleção de imagens** via galeria (Storage Access Framework) com consentimento.
- Compressão e envio de imagens **JPEG** (base64) com preview no destinatário e **salvar na galeria**.

## Componentes
- Android (Kotlin) — `app/`
- Servidor relay (Node.js + WebSocket) — `server/relay.js`

## Rodando o servidor
```bash
cd server
npm i ws
node relay.js
# Coloque por trás de Nginx com WSS em produção
```

## Configurar o App
Edite `MainActivity.kt` e ajuste:
```kotlin
private val SIGNAL_URL = "wss://SEU_DOMINIO_OU_IP:8080"
```
Abra no Android Studio (minSdk 24) e rode.

## Fluxo de uso
1. **Gerar Código (persistente)** no aparelho A e compartilhar com B.
2. B usa **Entrar com Código** — pareamento fica ativo até alguém **Revogar**.
3. Botão **Compartilhar Clipboard** (texto) → confirmação → envio.
4. Botão **Enviar Imagem** → escolhe na galeria → confirmação → envio.
5. Destinatário vê prévia de texto e imagem; pode **Copiar** (texto) ou **Salvar Imagem** na galeria.

## Privacidade & Ética
- Nada é lido/transferido sem **clique explícito** e confirmação.
- Código sem expiração aumenta responsabilidade: inclua **Revogar** quando necessário.
- Não armazene o conteúdo no servidor; apenas **transmita**. Logs só com metadados mínimos.

## Próximos passos (opcional)
- Mudar para **WebRTC DataChannel** (E2E real, sem relay do conteúdo).
- Limite de tamanho de imagem com chunking e barra de progresso.
- PIN adicional + biometria para abrir o app.
