
// Relay WebSocket com salas persistentes (sem expiração) e revogação manual.
const http = require('http');
const WebSocket = require('ws');

const server = http.createServer();
const wss = new WebSocket.Server({ server });

// code => { peers: Set<WebSocket> }
const rooms = new Map();

function genCode(){ return String(Math.floor(100000 + Math.random()*900000)); }

function createPersistent(ws) {
  const code = genCode();
  rooms.set(code, { peers: new Set([ws]) });
  ws.room = code;
  return { code };
}

function joinPersistent(ws, code) {
  const room = rooms.get(code);
  if (!room) return { error: 'Código inválido (não existe ou foi revogado).' };
  room.peers.add(ws);
  ws.room = code;
  room.peers.forEach(p => { if (p !== ws && p.readyState === WebSocket.OPEN) p.send(JSON.stringify({type:'peer-joined'})); });
  return { ok: true };
}

function relay(ws, msg) {
  const code = msg.code || ws.room;
  const room = rooms.get(code);
  if (!room) return;
  room.peers.forEach(p => { if (p !== ws && p.readyState === WebSocket.OPEN) p.send(JSON.stringify(msg)); });
}

function revoke(code) {
  const room = rooms.get(code);
  if (!room) return false;
  room.peers.forEach(p => { try{ p.send(JSON.stringify({type:'error', message:'Pareamento revogado pelo dono.'})); }catch(e){} p.close(); });
  rooms.delete(code);
  return true;
}

wss.on('connection', (ws) => {
  ws.on('message', (raw) => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch(e) { return; }

    if (msg.type === 'create_persistent') {
      const { code } = createPersistent(ws);
      ws.send(JSON.stringify({type:'created_persistent', code}));
      return;
    }
    if (msg.type === 'join_persistent') {
      const r = joinPersistent(ws, String(msg.code||''));
      if (r.error) ws.send(JSON.stringify({type:'error', message:r.error}));
      return;
    }
    if (msg.type === 'revoke') {
      const ok = revoke(String(msg.code||''));
      if (!ok) ws.send(JSON.stringify({type:'error', message:'Código inexistente'}));
      return;
    }
    if (msg.type === 'clipboard-push') {
      relay(ws, { type:'clipboard-push', text: String(msg.text||''), code: msg.code || ws.room });
      return;
    }
    if (msg.type === 'image-push') {
      // base64 (jpeg/webp) — cuidado com tamanhos muito grandes; chunking em produção
      relay(ws, { type:'image-push', base64: String(msg.base64||''), mime: String(msg.mime||'image/jpeg'), code: msg.code || ws.room });
      return;
    }
  });

  ws.on('close', () => {
    const code = ws.room;
    if (!code) return;
    const room = rooms.get(code);
    if (!room) return;
    room.peers.delete(ws);
    if (room.peers.size === 0) rooms.set(code, { peers: new Set() }); // mantém sala até revogação
  });
});

server.listen(8080, ()=> console.log('Relay persistente em ws://0.0.0.0:8080'));
